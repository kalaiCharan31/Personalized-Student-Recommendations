from flask import Flask, request, jsonify, render_template
import pandas as pd
from insights import generate_insights
from recommendations import create_recommendations

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['GET'])
def analyze():
    user_id = request.args.get('user_id')
    weak_areas, improvement_trends = generate_insights(user_id)
    response = {
        "improvement_trends": weak_areas.to_dict('records'),
        "weak_areas": improvement_trends.to_dict('records')
    }
    return jsonify(response)

@app.route('/recommend', methods=['GET'])
def recommend():
    user_id = request.args.get('user_id')
    recommendations, persona = create_recommendations(user_id)
    response = {
        "recommendations": recommendations,
        "persona": persona
    }
    return jsonify(response)

if __name__ == "__main__":
    app.run(debug=True)
