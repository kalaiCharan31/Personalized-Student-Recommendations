import pandas as pd
current_quiz_data = pd.read_csv('current_quiz_data.csv')
historical_quiz_data = pd.read_csv('historical_quiz_data.csv')
def analyze_data():
    current_analysis = current_quiz_data.describe()
    historical_analysis = historical_quiz_data.describe()
    return current_analysis, historical_analysis
if __name__ == "__main__":
    current_analysis, historical_analysis = analyze_data()
    print(current_analysis)
    print(historical_analysis)
