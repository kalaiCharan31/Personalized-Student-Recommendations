import pandas as pd
historical_quiz_data = pd.read_csv('historical_quiz_data.csv')
def generate_insights(user_id):
    user_data = historical_quiz_data[historical_quiz_data['user_id'] == int(user_id)]
    weak_areas = user_data[user_data['score'] < user_data['score'].mean()]
    improvement_trends = user_data[user_data['score'] > user_data['score'].mean()]
    
    return weak_areas, improvement_trends

if __name__ == "__main__":
    user_id = 1 
    weak_areas, improvement_trends = generate_insights(user_id)
    print("Weak Areas:\n", weak_areas)
    print("Improvement Trends:\n", improvement_trends)
