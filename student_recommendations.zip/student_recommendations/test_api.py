import requests

BASE_URL = "http://127.0.0.1:5000"

def test_analyze(user_id):
    response = requests.get(f"{BASE_URL}/analyze?user_id={user_id}")
    if response.status_code == 200:
        print("Analyze Response:", response.json())
    else:
        print("Failed to get analyze data")

def test_recommend(user_id):
    response = requests.get(f"{BASE_URL}/recommend?user_id={user_id}")
    if response.status_code == 200:
        print("Recommend Response:", response.json())
    else:
        print("Failed to get recommendations")

if __name__ == "__main__":
    user_id = 1 
    test_analyze(user_id)
    test_recommend(user_id)
