import pandas as pd
historical_quiz_data = pd.read_csv('historical_quiz_data.csv')
def create_recommendations(user_id):
    user_data = historical_quiz_data[historical_quiz_data['user_id'] == int(user_id)]
    focus_topics = user_data['topic'].value_counts().index.tolist()
    recommendations = {
        "focus_topics": focus_topics,
        "improvement_suggestions": "Practice more questions in weak areas.",
    }
    strengths = ', '.join(focus_topics[:2]) if focus_topics else "N/A"
    weaknesses = ', '.join(focus_topics[-2:]) if len(focus_topics) > 1 else "N/A"
    persona = {
        "label": f"Strengths in {strengths} and weaknesses in {weaknesses}",
        "strengths": strengths,
        "weaknesses": weaknesses,
    }
    
    return recommendations, persona

if __name__ == "__main__":
    user_id = 1  
    recommendations, persona = create_recommendations(user_id)
    print("Recommendations:\n", recommendations)
    print("Persona:\n", persona)
